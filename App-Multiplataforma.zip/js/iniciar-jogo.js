var selBtnIniciar = document.querySelector(".btn-iniciar");
selBtnIniciar.addEventListener("click",function(){
	
})